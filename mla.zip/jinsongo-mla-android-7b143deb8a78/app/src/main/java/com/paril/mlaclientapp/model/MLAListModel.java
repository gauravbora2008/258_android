package com.paril.mlaclientapp.model;

/**
 * Created by paril on 7/11/2017.
 */
public class MLAListModel {

    private String txtView;

    public MLAListModel(String txtView) {
        this.txtView = txtView;
    }

    public String getTxtView() {
        return txtView;
    }

}