package com.paril.mlaclientapp.ui.adapter;

public interface OnItemClickListener<T> {
    void onItemClick(T item,int resourceId);

}
